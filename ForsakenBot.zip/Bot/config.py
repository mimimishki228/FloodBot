# bot/config.py (БЕЗОПАСНАЯ ВЕРСИЯ)
import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # Берем всё из переменных окружения
    BOT_TOKEN = os.getenv('BOT_TOKEN')
    OWNER_IDS = [int(x) for x in os.getenv('OWNER_IDS', '').split(',') if x]
    INFO_CHANNEL_ID = os.getenv('INFO_CHANNEL_ID')
    FLOOD_GROUP_ID = os.getenv('FLOOD_GROUP_ID')
    STAFF_CHANNEL_ID = os.getenv('STAFF_CHANNEL_ID')
    LOGS_CHANNEL_ID = os.getenv('LOGS_CHANNEL_ID')
    FLOOD_GROUP_LINK = os.getenv('FLOOD_GROUP_LINK')
    STAFF_CHANNEL_LINK = os.getenv('STAFF_CHANNEL_LINK')