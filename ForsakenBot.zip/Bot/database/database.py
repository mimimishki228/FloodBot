# bot/database.py
import aiosqlite
import json
from datetime import datetime
from typing import Optional, List, Dict, Any
from config import config

DB_PATH = config.DATABASE_PATH

async def init_db():
    """Создает все таблицы при первом запуске"""
    async with aiosqlite.connect(DB_PATH) as db:
        # Таблица пользователей
        await db.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                full_name TEXT,
                role TEXT DEFAULT 'участник',
                flood_role TEXT,
                staff_role TEXT,
                is_flood_member BOOLEAN DEFAULT 0,
                is_banned BOOLEAN DEFAULT 0,
                rest_until DATE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Таблица заявок
        await db.execute('''
            CREATE TABLE IF NOT EXISTS applications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                type TEXT,  -- 'flood', 'staff', 'rest'
                status TEXT DEFAULT 'pending',  -- 'pending', 'accepted', 'rejected'
                form_data TEXT,  -- JSON с анкетой
                admin_id INTEGER,
                admin_comment TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Таблица настроек
        await db.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        ''')
        
        # Таблица рестов
        await db.execute('''
            CREATE TABLE IF NOT EXISTS rests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                start_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                end_date TIMESTAMP,
                is_active BOOLEAN DEFAULT 1
            )
        ''')
        
        # Таблица логов (для хранения в БД)
        await db.execute('''
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                action TEXT,
                details TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Добавляем владельцев из конфига
        for owner_id in config.OWNER_IDS:
            await db.execute('''
                INSERT OR REPLACE INTO users (user_id, role)
                VALUES (?, 'владелец')
            ''', (owner_id,))
        
        # Добавляем настройки по умолчанию
        await db.execute('''
            INSERT OR IGNORE INTO settings (key, value)
            VALUES 
                ('flood_open', '1'),
                ('flood_roles', '["Шедлетский","Занято","Бронь"]'),
                ('staff_roles', '["Младший Админ","Медиа","Чистка"]')
        ''', ())
        
        await db.commit()

# ============ РАБОТА С ПОЛЬЗОВАТЕЛЯМИ ============

async def get_user(user_id: int) -> Optional[Dict]:
    """Получает данные пользователя"""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            'SELECT * FROM users WHERE user_id = ?', (user_id,)
        ) as cursor:
            row = await cursor.fetchone()
            if row:
                columns = ['user_id', 'username', 'full_name', 'role', 'flood_role', 
                          'staff_role', 'is_flood_member', 'is_banned', 'rest_until', 'created_at']
                return dict(zip(columns, row))
            return None

async def create_user(user_id: int, username: str = None, full_name: str = None):
    """Создает нового пользователя"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('''
            INSERT OR IGNORE INTO users (user_id, username, full_name)
            VALUES (?, ?, ?)
        ''', (user_id, username, full_name))
        await db.commit()

async def update_user_role(user_id: int, role: str):
    """Обновляет роль пользователя"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            'UPDATE users SET role = ? WHERE user_id = ?',
            (role, user_id)
        )
        await db.commit()

async def get_user_role(user_id: int) -> str:
    """Получает роль пользователя"""
    user = await get_user(user_id)
    return user['role'] if user else 'участник'

async def is_admin(user_id: int) -> bool:
    """Проверяет, является ли пользователь админом или владельцем"""
    role = await get_user_role(user_id)
    return role in ['админ', 'владелец']

async def is_owner(user_id: int) -> bool:
    """Проверяет, является ли пользователь владельцем"""
    role = await get_user_role(user_id)
    return role == 'владелец'

async def is_banned(user_id: int) -> bool:
    """Проверяет, забанен ли пользователь"""
    user = await get_user(user_id)
    return user['is_banned'] == 1 if user else False

# ============ РАБОТА С ЗАЯВКАМИ ============

async def create_application(user_id: int, app_type: str, form_data: Dict) -> int:
    """Создает новую заявку"""
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute('''
            INSERT INTO applications (user_id, type, form_data)
            VALUES (?, ?, ?)
        ''', (user_id, app_type, json.dumps(form_data, ensure_ascii=False)))
        await db.commit()
        return cursor.lastrowid

async def get_application(app_id: int) -> Optional[Dict]:
    """Получает заявку по ID"""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            'SELECT * FROM applications WHERE id = ?', (app_id,)
        ) as cursor:
            row = await cursor.fetchone()
            if row:
                columns = ['id', 'user_id', 'type', 'status', 'form_data', 
                          'admin_id', 'admin_comment', 'created_at', 'updated_at']
                data = dict(zip(columns, row))
                data['form_data'] = json.loads(data['form_data'])
                return data
            return None

async def get_pending_applications(app_type: str = None) -> List[Dict]:
    """Получает все pending заявки (опционально по типу)"""
    async with aiosqlite.connect(DB_PATH) as db:
        query = 'SELECT * FROM applications WHERE status = "pending"'
        params = []
        if app_type:
            query += ' AND type = ?'
            params.append(app_type)
        query += ' ORDER BY created_at ASC'
        
        async with db.execute(query, params) as cursor:
            rows = await cursor.fetchall()
            columns = ['id', 'user_id', 'type', 'status', 'form_data', 
                      'admin_id', 'admin_comment', 'created_at', 'updated_at']
            apps = []
            for row in rows:
                data = dict(zip(columns, row))
                data['form_data'] = json.loads(data['form_data'])
                apps.append(data)
            return apps

async def update_application_status(app_id: int, status: str, admin_id: int, comment: str = None):
    """Обновляет статус заявки"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('''
            UPDATE applications 
            SET status = ?, admin_id = ?, admin_comment = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (status, admin_id, comment, app_id))
        await db.commit()

# ============ РАБОТА С НАСТРОЙКАМИ ============

async def get_setting(key: str) -> Optional[str]:
    """Получает настройку"""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            'SELECT value FROM settings WHERE key = ?', (key,)
        ) as cursor:
            row = await cursor.fetchone()
            return row[0] if row else None

async def set_setting(key: str, value: str):
    """Устанавливает настройку"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('''
            INSERT OR REPLACE INTO settings (key, value)
            VALUES (?, ?)
        ''', (key, value))
        await db.commit()

async def get_flood_roles() -> List[str]:
    """Получает список ролей для флуда"""
    roles_json = await get_setting('flood_roles')
    return json.loads(roles_json) if roles_json else []

async def get_staff_roles() -> List[str]:
    """Получает список ролей для стаффа"""
    roles_json = await get_setting('staff_roles')
    return json.loads(roles_json) if roles_json else []

async def is_flood_open() -> bool:
    """Проверяет, открыт ли набор во флуд"""
    value = await get_setting('flood_open')
    return value == '1'

# ============ РАБОТА С РЕСТАМИ ============

async def create_rest(user_id: int, days: int):
    """Создает рест для пользователя"""
    from datetime import datetime, timedelta
    
    end_date = datetime.now() + timedelta(days=days)
    
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('''
            INSERT INTO rests (user_id, end_date)
            VALUES (?, ?)
        ''', (user_id, end_date.isoformat()))
        
        await db.execute('''
            UPDATE users SET rest_until = ? WHERE user_id = ?
        ''', (end_date.isoformat(), user_id))
        
        await db.commit()

async def get_active_rests() -> List[Dict]:
    """Получает все активные ресты"""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute('''
            SELECT * FROM rests WHERE is_active = 1
            ORDER BY end_date ASC
        ''') as cursor:
            rows = await cursor.fetchall()
            columns = ['id', 'user_id', 'start_date', 'end_date', 'is_active']
            return [dict(zip(columns, row)) for row in rows]

# ============ ЛОГИ В БД ============

async def add_log(user_id: int, action: str, details: str = None):
    """Добавляет лог в базу данных"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('''
            INSERT INTO logs (user_id, action, details)
            VALUES (?, ?, ?)
        ''', (user_id, action, details))
        await db.commit()

# bot/database.py (дополняем)

# ============ ПОЛУЧЕНИЕ ПОЛЬЗОВАТЕЛЕЙ ПО РОЛЯМ ============

async def get_users_by_flood_role(role: str) -> List[Dict]:
    """Получает всех пользователей с данной ролью во флуде"""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            'SELECT * FROM users WHERE flood_role = ? AND is_banned = 0',
            (role,)
        ) as cursor:
            rows = await cursor.fetchall()
            columns = ['user_id', 'username', 'full_name', 'role', 'flood_role', 
                      'staff_role', 'is_flood_member', 'is_banned', 'rest_until', 'created_at']
            return [dict(zip(columns, row)) for row in rows]

async def get_users_by_staff_role(role: str) -> List[Dict]:
    """Получает всех пользователей с данной ролью в стаффе"""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            'SELECT * FROM users WHERE staff_role = ? AND is_banned = 0',
            (role,)
        ) as cursor:
            rows = await cursor.fetchall()
            columns = ['user_id', 'username', 'full_name', 'role', 'flood_role', 
                      'staff_role', 'is_flood_member', 'is_banned', 'rest_until', 'created_at']
            return [dict(zip(columns, row)) for row in rows]

async def get_all_admins() -> List[Dict]:
    """Получает всех админов"""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            'SELECT * FROM users WHERE role = "админ"'
        ) as cursor:
            rows = await cursor.fetchall()
            columns = ['user_id', 'username', 'full_name', 'role', 'flood_role', 
                      'staff_role', 'is_flood_member', 'is_banned', 'rest_until', 'created_at']
            return [dict(zip(columns, row)) for row in rows]

# ============ УДАЛЕНИЕ РОЛЕЙ У ПОЛЬЗОВАТЕЛЕЙ ============

async def remove_flood_role_from_users(role: str):
    """Убирает роль флуда у всех пользователей"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            'UPDATE users SET flood_role = NULL WHERE flood_role = ?',
            (role,)
        )
        await db.commit()

async def remove_staff_role_from_users(role: str):
    """Убирает роль стаффа у всех пользователей"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            'UPDATE users SET staff_role = NULL WHERE staff_role = ?',
            (role,)
        )
        await db.commit()

# ============ ПОЛУЧЕНИЕ ПОЛЬЗОВАТЕЛЕЙ ДЛЯ ИНФО ============

async def get_all_users_with_flood_roles() -> List[Dict]:
    """Получает всех пользователей с ролями флуда"""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            'SELECT * FROM users WHERE flood_role IS NOT NULL AND is_banned = 0'
        ) as cursor:
            rows = await cursor.fetchall()
            columns = ['user_id', 'username', 'full_name', 'role', 'flood_role', 
                      'staff_role', 'is_flood_member', 'is_banned', 'rest_until', 'created_at']
            return [dict(zip(columns, row)) for row in rows]

# bot/database.py (дополняем)

async def get_user_by_username(username: str) -> Optional[Dict]:
    """Получает пользователя по username"""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            'SELECT * FROM users WHERE username = ?',
            (username,)
        ) as cursor:
            row = await cursor.fetchone()
            if row:
                columns = ['user_id', 'username', 'full_name', 'role', 'flood_role', 
                          'staff_role', 'is_flood_member', 'is_banned', 'rest_until', 'created_at']
                return dict(zip(columns, row))
            return None