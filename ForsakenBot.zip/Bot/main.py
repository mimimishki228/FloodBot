# bot/main.py
import asyncio
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from config import config
from database import init_db, get_user, create_user, get_user_role, is_banned
from keyboards import get_main_menu, get_flood_menu, get_back_button
from handlers import start, flood, staff, rest, support, admin, owner
from middlewares.anti_spam import AntiSpamMiddleware
from utils.logger import Logger

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Инициализация бота
bot = Bot(token=config.BOT_TOKEN)
dp = Dispatcher()

# Инициализация логгера
logger_system = Logger(bot, config.LOGS_CHANNEL)

# Подключаем middleware для анти-спама
dp.message.middleware(AntiSpamMiddleware(
    limit=config.SPAM_LIMIT,
    window=config.SPAM_WINDOW,
    block_time=config.SPAM_BLOCK_TIME
))

# ============ ХЕНДЛЕРЫ ============

@dp.message(Command("start"))
async def cmd_start(message: Message):
    """Обработчик команды /start"""
    user = message.from_user
    
    # Создаем пользователя в БД
    await create_user(user.id, user.username, user.full_name)
    
    # Проверяем бан
    if await is_banned(user.id):
        await message.answer("🚫 Вы забанены! Доступ запрещен.")
        return
    
    # Логируем
    await logger_system.log_start(user)
    
    # Отправляем приветствие
    await message.answer(
        f"👋 Привет, {user.full_name}!\n\n"
        f"Я бот для управления флудом.\n"
        f"Выберите действие в меню ниже:",
        reply_markup=await get_main_menu(user.id)
    )

@dp.callback_query(lambda c: c.data == "back_to_main")
async def back_to_main(call: CallbackQuery):
    """Возврат в главное меню"""
    await call.message.edit_text(
        "👋 Главное меню:\n\nВыберите действие:",
        reply_markup=await get_main_menu(call.from_user.id)
    )
    await call.answer()

@dp.callback_query(lambda c: c.data == "menu_flood")
async def menu_flood(call: CallbackQuery):
    """Меню Flood"""
    await call.message.edit_text(
        "🌊 Раздел Flood:\n\n"
        "Выберите действие:",
        reply_markup=await get_flood_menu(call.from_user.id)
    )
    await call.answer()

@dp.callback_query(lambda c: c.data == "menu_info")
async def menu_info(call: CallbackQuery):
    """Информация (заглушка)"""
    await call.message.edit_text(
        "ℹ️ Информация:\n\n"
        "Здесь будет информация о боте...",
        reply_markup=get_back_button()
    )
    await call.answer()

# ============ ЗАПУСК БОТА ============

async def on_startup():
    """Действия при запуске бота"""
    logger.info("Инициализация базы данных...")
    await init_db()
    logger.info("База данных готова!")
    
    # Запускаем фоновые задачи
    asyncio.create_task(check_rest_expiration())
    
    logger.info("Бот запущен!")

async def check_rest_expiration():
    """Проверяет истекшие ресты"""
    from database import get_active_rests, update_user_role
    from datetime import datetime
    
    while True:
        try:
            rests = await get_active_rests()
            now = datetime.now()
            
            for rest in rests:
                end_date = datetime.fromisoformat(rest['end_date'])
                if now >= end_date:
                    # Рест истек
                    await update_user_role(rest['user_id'], 'участник')
                    # Логика удаления из группы
                    # ...
                    logger.info(f"Рест истек для пользователя {rest['user_id']}")
        except Exception as e:
            logger.error(f"Ошибка проверки рестов: {e}")
        
        await asyncio.sleep(60)  # Проверяем каждую минуту

async def main():
    """Главная функция"""
    # Подключаем обработчики
    dp.include_router(start.router)
    dp.include_router(flood.router)
    dp.include_router(staff.router)
    dp.include_router(rest.router)
    dp.include_router(support.router)
    dp.include_router(admin.router)
    dp.include_router(owner.router)
    
    # Запускаем бота
    await on_startup()
    await dp.start_polling(bot, skip_updates=True)

if __name__ == "__main__":
    asyncio.run(main())

# bot/main.py (дополняем)
from utils.info_manager import InfoManager

# Создаем менеджер Info канала
info_manager = InfoManager(bot)

# Сохраняем в dp для доступа из хендлеров
dp['info_manager'] = info_manager
dp['logger'] = logger_system

# ============ ОБНОВЛЯЕМ КОМАНДУ /START ============

@dp.message(Command("start"))
async def cmd_start(message: Message):
    user = message.from_user
    
    await create_user(user.id, user.username, user.full_name)
    
    if await is_banned(user.id):
        await message.answer("🚫 Вы забанены! Доступ запрещен.")
        return
    
    # Логируем
    await logger_system.log_start(user)
    
    # Отправляем ссылку на Info канал
    info_link = config.INFO_CHANNEL
    
    await message.answer(
        f"👋 Привет, {user.full_name}!\n\n"
        f"📢 <b>Info канал:</b> <a href='{info_link}'>Перейти</a>\n\n"
        f"Выберите действие в меню ниже:",
        reply_markup=await get_main_menu(user.id),
        parse_mode="HTML"
    )

# bot/main.py (дополняем)
from handlers import start, flood, staff, rest, support, admin, owner

# ... в конце файла, перед запуском:
dp.include_router(start.router)
dp.include_router(flood.router)
dp.include_router(staff.router)
dp.include_router(rest.router)
dp.include_router(support.router)
dp.include_router(admin.router)
dp.include_router(owner.router)