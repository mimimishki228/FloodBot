# bot/handlers/owner.py
from aiogram import Router, F, types
from aiogram.types import CallbackQuery, Message
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import json

from database import (
    get_user, update_user_role, get_all_admins,
    get_flood_roles, get_staff_roles, set_setting,
    is_owner, get_user_role
)
from keyboards import (
    get_owner_panel, get_remove_role_menu, 
    get_remove_admin_menu, get_back_button,
    get_config_menu
)
from utils.info_manager import InfoManager
from utils.logger import Logger

router = Router()

# ============ FSM ДЛЯ ДОБАВЛЕНИЯ АДМИНА ============

class AddAdminStates(StatesGroup):
    waiting_for_user_id = State()

# ============ ПАНЕЛЬ ВЛАДЕЛЬЦА ============

@router.callback_query(F.data == "menu_owner")
async def menu_owner(call: CallbackQuery):
    """Открывает панель владельца"""
    user_id = call.from_user.id
    
    if not await is_owner(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    await call.message.edit_text(
        "👑 <b>Панель владельца</b>\n\n"
        "Выберите действие:",
        reply_markup=await get_owner_panel(user_id),
        parse_mode="HTML"
    )
    await call.answer()

# ============ УДАЛЕНИЕ АДМИНА ============

@router.callback_query(F.data == "owner_remove_admin")
async def owner_remove_admin(call: CallbackQuery):
    """Показывает список админов для удаления"""
    user_id = call.from_user.id
    
    if not await is_owner(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    admins = await get_all_admins()
    
    if not admins:
        await call.message.edit_text(
            "📭 Нет админов для удаления.",
            reply_markup=get_back_button("back_to_owner")
        )
        await call.answer()
        return
    
    await call.message.edit_text(
        "👥 <b>Выберите админа для удаления:</b>",
        reply_markup=await get_remove_admin_menu(),
        parse_mode="HTML"
    )
    await call.answer()

@router.callback_query(F.data.startswith("remove_admin_"))
async def remove_admin_action(call: CallbackQuery):
    """Удаляет админа"""
    owner_id = call.from_user.id
    
    if not await is_owner(owner_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    admin_id = int(call.data.split("_")[2])
    
    # Не даем удалить владельца
    if await is_owner(admin_id):
        await call.answer("❌ Нельзя удалить владельца!", show_alert=True)
        return
    
    # Получаем данные админа
    admin = await get_user(admin_id)
    if not admin or admin['role'] != 'админ':
        await call.answer("❌ Пользователь не является админом!", show_alert=True)
        return
    
    # Удаляем права админа
    await update_user_role(admin_id, 'участник')
    
    # Получаем логгер
    logger: Logger = call.bot.data.get('logger')
    await logger.log_remove_admin(
        owner=call.from_user,
        admin=types.User(id=admin_id, username=admin.get('username'), full_name=admin.get('full_name', 'Unknown'))
    )
    
    # Обновляем Info канал (если нужно)
    info_manager: InfoManager = call.bot.data.get('info_manager')
    # Если в инфо есть список админов - обновляем
    # await info_manager.update_staff()  # если админы отображаются в стаффе
    
    await call.message.edit_text(
        f"✅ Админ @{admin.get('username', admin_id)} удален!",
        reply_markup=await get_owner_panel(owner_id)
    )
    await call.answer()

# ============ УДАЛЕНИЕ РОЛИ ============

@router.callback_query(F.data == "owner_remove_role")
async def owner_remove_role(call: CallbackQuery):
    """Показывает выбор типа роли для удаления"""
    user_id = call.from_user.id
    
    if not await is_owner(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton("🌸 Удалить роль флуда", callback_data="remove_role_flood")],
            [InlineKeyboardButton("👔 Удалить роль стаффа", callback_data="remove_role_staff")],
            [InlineKeyboardButton("🔙 Назад", callback_data="back_to_owner")]
        ]
    )
    
    await call.message.edit_text(
        "🗑️ <b>Выберите тип роли для удаления:</b>",
        reply_markup=keyboard,
        parse_mode="HTML"
    )
    await call.answer()

@router.callback_query(F.data == "remove_role_flood")
async def remove_role_flood_menu(call: CallbackQuery):
    """Показывает список ролей флуда для удаления"""
    user_id = call.from_user.id
    
    if not await is_owner(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    roles = await get_flood_roles()
    
    if not roles:
        await call.message.edit_text(
            "📭 Нет ролей флуда для удаления.",
            reply_markup=get_back_button("back_to_owner")
        )
        await call.answer()
        return
    
    await call.message.edit_text(
        "🌸 <b>Выберите роль флуда для удаления:</b>\n\n"
        "⚠️ <i>Все пользователи с этой ролью потеряют её!</i>",
        reply_markup=await get_remove_role_menu('flood'),
        parse_mode="HTML"
    )
    await call.answer()

@router.callback_query(F.data == "remove_role_staff")
async def remove_role_staff_menu(call: CallbackQuery):
    """Показывает список ролей стаффа для удаления"""
    user_id = call.from_user.id
    
    if not await is_owner(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    roles = await get_staff_roles()
    
    if not roles:
        await call.message.edit_text(
            "📭 Нет ролей стаффа для удаления.",
            reply_markup=get_back_button("back_to_owner")
        )
        await call.answer()
        return
    
    await call.message.edit_text(
        "👔 <b>Выберите роль стаффа для удаления:</b>\n\n"
        "⚠️ <i>Все пользователи с этой ролью потеряют её!</i>",
        reply_markup=await get_remove_role_menu('staff'),
        parse_mode="HTML"
    )
    await call.answer()

@router.callback_query(F.data.startswith("remove_flood_role_"))
async def remove_flood_role_action(call: CallbackQuery):
    """Удаляет роль флуда"""
    owner_id = call.from_user.id
    
    if not await is_owner(owner_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    role = call.data.replace("remove_flood_role_", "")
    
    # Получаем менеджер Info
    info_manager: InfoManager = call.bot.data.get('info_manager')
    
    # Удаляем роль
    success = await info_manager.remove_flood_role(role)
    
    if not success:
        await call.answer("❌ Роль не найдена!", show_alert=True)
        return
    
    # Логируем
    logger: Logger = call.bot.data.get('logger')
    await logger.log_config_change(
        owner=call.from_user,
        config_type='flood_roles',
        old_data={'role': role},
        new_data={'role': 'удалена'}
    )
    
    await call.message.edit_text(
        f"✅ Роль <b>{role}</b> успешно удалена!\n"
        f"Все пользователи с этой ролью были обновлены.",
        reply_markup=await get_owner_panel(owner_id),
        parse_mode="HTML"
    )
    await call.answer()

@router.callback_query(F.data.startswith("remove_staff_role_"))
async def remove_staff_role_action(call: CallbackQuery):
    """Удаляет роль стаффа"""
    owner_id = call.from_user.id
    
    if not await is_owner(owner_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    role = call.data.replace("remove_staff_role_", "")
    
    # Получаем менеджер Info
    info_manager: InfoManager = call.bot.data.get('info_manager')
    
    # Удаляем роль
    success = await info_manager.remove_staff_role(role)
    
    if not success:
        await call.answer("❌ Роль не найдена!", show_alert=True)
        return
    
    # Логируем
    logger: Logger = call.bot.data.get('logger')
    await logger.log_config_change(
        owner=call.from_user,
        config_type='staff_roles',
        old_data={'role': role},
        new_data={'role': 'удалена'}
    )
    
    await call.message.edit_text(
        f"✅ Роль <b>{role}</b> успешно удалена!\n"
        f"Все пользователи с этой ролью были обновлены.",
        reply_markup=await get_owner_panel(owner_id),
        parse_mode="HTML"
    )
    await call.answer()

# ============ ДОБАВЛЕНИЕ АДМИНА ============

@router.callback_query(F.data == "owner_add_admin")
async def owner_add_admin(call: CallbackQuery, state: FSMContext):
    """Начинает процесс добавления админа"""
    user_id = call.from_user.id
    
    if not await is_owner(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    await call.message.edit_text(
        "➕ <b>Добавление админа</b>\n\n"
        "Отправьте ID пользователя или его @username:\n"
        "Например: <code>123456789</code> или <code>@username</code>",
        reply_markup=get_back_button("back_to_owner"),
        parse_mode="HTML"
    )
    await state.set_state(AddAdminStates.waiting_for_user_id)
    await call.answer()

@router.message(AddAdminStates.waiting_for_user_id)
async def process_add_admin(message: Message, state: FSMContext):
    """Обрабатывает ввод ID пользователя для добавления админа"""
    user_id = message.from_user.id
    
    if not await is_owner(user_id):
        await message.answer("❌ У вас нет доступа!")
        return
    
    text = message.text.strip()
    
    # Парсим ID или username
    target_id = None
    
    if text.startswith('@'):
        # Это username
        username = text[1:]
        from database import get_user_by_username
        user = await get_user_by_username(username)
        if user:
            target_id = user['user_id']
    else:
        # Это ID
        try:
            target_id = int(text)
        except ValueError:
            await message.answer(
                "❌ Неверный формат!\n"
                "Отправьте ID или @username.",
                reply_markup=get_back_button("back_to_owner")
            )
            return
    
    if not target_id:
        await message.answer(
            "❌ Пользователь не найден!",
            reply_markup=get_back_button("back_to_owner")
        )
        return
    
    # Проверяем, не владелец ли уже
    if await is_owner(target_id):
        await message.answer(
            "❌ Этот пользователь уже владелец!",
            reply_markup=get_back_button("back_to_owner")
        )
        await state.clear()
        return
    
    # Проверяем, не админ ли уже
    if await get_user_role(target_id) == 'админ':
        await message.answer(
            "❌ Этот пользователь уже админ!",
            reply_markup=get_back_button("back_to_owner")
        )
        await state.clear()
        return
    
    # Назначаем админом
    await update_user_role(target_id, 'админ')
    
    # Получаем данные пользователя
    target_user = await get_user(target_id)
    
    # Логируем
    logger: Logger = message.bot.data.get('logger')
    await logger.log_add_admin(
        owner=message.from_user,
        new_admin=types.User(
            id=target_id,
            username=target_user.get('username'),
            full_name=target_user.get('full_name', 'Unknown')
        )
    )
    
    await message.answer(
        f"✅ Пользователь @{target_user.get('username', target_id)} назначен админом!",
        reply_markup=await get_owner_panel(user_id)
    )
    await state.clear()

# ============ КОНФИГ ============

@router.callback_query(F.data == "owner_config")
async def owner_config(call: CallbackQuery):
    """Открывает меню конфигурации"""
    user_id = call.from_user.id
    
    if not await is_owner(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    await call.message.edit_text(
        "⚙️ <b>Конфигурация</b>\n\n"
        "Выберите что настроить:",
        reply_markup=get_config_menu(),
        parse_mode="HTML"
    )
    await call.answer()

@router.callback_query(F.data == "config_flood_roles")
async def config_flood_roles(call: CallbackQuery):
    """Показывает и позволяет изменить роли флуда"""
    user_id = call.from_user.id
    
    if not await is_owner(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    roles = await get_flood_roles()
    roles_text = "\n".join([f"• {role}" for role in roles]) if roles else "Нет ролей"
    
    await call.message.edit_text(
        f"🌸 <b>Роли флуда</b>\n\n"
        f"Текущие роли:\n{roles_text}\n\n"
        f"Чтобы изменить, отправьте новые роли через запятую:\n"
        f"<code>Шедлетский, Занято, Бронь</code>",
        reply_markup=get_back_button("back_to_owner"),
        parse_mode="HTML"
    )
    await call.answer()

# ============ УНИЧТОЖЕНИЕ ============

@router.callback_query(F.data == "owner_destroy")
async def owner_destroy(call: CallbackQuery):
    """Снимает права админов у всех, кроме владельцев"""
    user_id = call.from_user.id
    
    if not await is_owner(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    # Подтверждение
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("✅ Да, уничтожить!", callback_data="destroy_confirm"),
                InlineKeyboardButton("❌ Отмена", callback_data="back_to_owner")
            ]
        ]
    )
    
    await call.message.edit_text(
        "💥 <b>ВНИМАНИЕ!</b>\n\n"
        "Вы собираетесь снять права администратора у ВСЕХ админов.\n"
        "Это действие НЕОБРАТИМО!\n\n"
        "Вы уверены?",
        reply_markup=keyboard,
        parse_mode="HTML"
    )
    await call.answer()

@router.callback_query(F.data == "destroy_confirm")
async def destroy_confirm(call: CallbackQuery):
    """Подтверждение уничтожения"""
    owner_id = call.from_user.id
    
    if not await is_owner(owner_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    # Снимаем админов
    from database import get_all_admins
    
    admins = await get_all_admins()
    
    for admin in admins:
        if not await is_owner(admin['user_id']):  # Не трогаем владельцев
            await update_user_role(admin['user_id'], 'участник')
    
    # Логируем
    logger: Logger = call.bot.data.get('logger')
    await logger.log_owner_action(
        owner=call.from_user,
        action='УНИЧТОЖЕНИЕ',
        details=f"Сняты права у {len(admins)} админов"
    )
    
    await call.message.edit_text(
        f"💥 <b>УНИЧТОЖЕНИЕ ВЫПОЛНЕНО!</b>\n\n"
        f"Сняты права админа у {len(admins)} пользователей.",
        reply_markup=await get_owner_panel(owner_id),
        parse_mode="HTML"
    )
    await call.answer()

# ============ ОЧИСТКА INFO КАНАЛА ============

@router.callback_query(F.data == "owner_clear_info")
async def owner_clear_info(call: CallbackQuery):
    """Очищает все сообщения в Info канале"""
    user_id = call.from_user.id
    
    if not await is_owner(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    # Подтверждение
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("✅ Да, очистить!", callback_data="clear_info_confirm"),
                InlineKeyboardButton("❌ Отмена", callback_data="back_to_owner")
            ]
        ]
    )
    
    await call.message.edit_text(
        "🗑️ <b>ВНИМАНИЕ!</b>\n\n"
        "Вы собираетесь удалить ВСЕ сообщения бота в Info канале\n"
        "и создать их заново.\n\n"
        "Вы уверены?",
        reply_markup=keyboard,
        parse_mode="HTML"
    )
    await call.answer()

@router.callback_query(F.data == "clear_info_confirm")
async def clear_info_confirm(call: CallbackQuery):
    """Подтверждение очистки Info канала"""
    owner_id = call.from_user.id
    
    if not await is_owner(owner_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    info_manager: InfoManager = call.bot.data.get('info_manager')
    
    # Очищаем канал
    success = await info_manager.clear_all_messages()
    
    if success:
        await call.message.edit_text(
            "✅ Info канал успешно очищен и обновлен!",
            reply_markup=await get_owner_panel(owner_id)
        )
    else:
        await call.message.edit_text(
            "❌ Ошибка при очистке канала!",
            reply_markup=await get_owner_panel(owner_id)
        )
    
    await call.answer()

# ============ НАЗАД ============

@router.callback_query(F.data == "back_to_owner")
async def back_to_owner(call: CallbackQuery):
    """Возврат в панель владельца"""
    user_id = call.from_user.id
    
    if not await is_owner(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    await call.message.edit_text(
        "👑 <b>Панель владельца</b>\n\n"
        "Выберите действие:",
        reply_markup=await get_owner_panel(user_id),
        parse_mode="HTML"
    )
    await call.answer()