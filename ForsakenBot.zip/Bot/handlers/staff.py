# bot/handlers/staff.py
import json
import re
from aiogram import Router, F, types
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database import (
    get_user, get_user_role, create_application,
    get_application, update_application_status,
    get_pending_applications, get_staff_roles,
    update_user_role, is_banned, get_all_admins
)
from keyboards import get_flood_menu, get_back_button, get_cancel_button
from utils.info_manager import InfoManager
from utils.logger import Logger
from config import config

router = Router()

# ============ FSM ДЛЯ АНКЕТЫ В СТАФФ ============

class StaffApplicationStates(StatesGroup):
    waiting_for_name = State()
    waiting_for_age = State()
    waiting_for_experience = State()
    waiting_for_skills = State()
    waiting_for_reason = State()
    waiting_for_confirm = State()

# ============ ЗАЯВКА В СТАФФ ============

@router.callback_query(F.data == "staff_apply")
async def staff_apply(call: CallbackQuery, state: FSMContext):
    """Начинает процесс подачи заявки в стафф"""
    user_id = call.from_user.id
    
    # Проверяем бан
    if await is_banned(user_id):
        await call.answer("🚫 Вы забанены!", show_alert=True)
        return
    
    # Проверяем, не в стаффе ли уже
    user = await get_user(user_id)
    if user and user.get('staff_role'):
        await call.answer("✅ Вы уже в стаффе!", show_alert=True)
        return
    
    await call.message.edit_text(
        "👔 <b>Заявка в стафф</b>\n\n"
        "Заполните анкету для вступления в стафф.\n"
        "Отвечайте на вопросы.\n\n"
        "Для отмены нажмите кнопку ниже.",
        reply_markup=get_cancel_button(),
        parse_mode="HTML"
    )
    
    await call.message.answer(
        "📝 <b>Вопрос 1:</b>\n"
        "Как вас называть? (Имя или ник)",
        parse_mode="HTML"
    )
    
    await state.set_state(StaffApplicationStates.waiting_for_name)
    await call.answer()

@router.message(StaffApplicationStates.waiting_for_name)
async def process_staff_name(message: Message, state: FSMContext):
    """Обрабатывает имя"""
    await state.update_data(name=message.text)
    
    await message.answer(
        "📝 <b>Вопрос 2:</b>\n"
        "Сколько вам лет?",
        parse_mode="HTML"
    )
    
    await state.set_state(StaffApplicationStates.waiting_for_age)

@router.message(StaffApplicationStates.waiting_for_age)
async def process_staff_age(message: Message, state: FSMContext):
    """Обрабатывает возраст"""
    if not message.text.isdigit():
        await message.answer("❌ Введите число!")
        return
    
    await state.update_data(age=int(message.text))
    
    await message.answer(
        "📝 <b>Вопрос 3:</b>\n"
        "Какой у вас опыт в стаффе или подобных проектах?",
        parse_mode="HTML"
    )
    
    await state.set_state(StaffApplicationStates.waiting_for_experience)

@router.message(StaffApplicationStates.waiting_for_experience)
async def process_staff_experience(message: Message, state: FSMContext):
    """Обрабатывает опыт"""
    await state.update_data(experience=message.text)
    
    await message.answer(
        "📝 <b>Вопрос 4:</b>\n"
        "Какие у вас навыки? (Что вы умеете делать)",
        parse_mode="HTML"
    )
    
    await state.set_state(StaffApplicationStates.waiting_for_skills)

@router.message(StaffApplicationStates.waiting_for_skills)
async def process_staff_skills(message: Message, state: FSMContext):
    """Обрабатывает навыки"""
    await state.update_data(skills=message.text)
    
    await message.answer(
        "📝 <b>Вопрос 5:</b>\n"
        "Почему вы хотите стать частью стаффа?",
        parse_mode="HTML"
    )
    
    await state.set_state(StaffApplicationStates.waiting_for_reason)

@router.message(StaffApplicationStates.waiting_for_reason)
async def process_staff_reason(message: Message, state: FSMContext):
    """Обрабатывает причину"""
    await state.update_data(reason=message.text)
    
    # Получаем все данные
    data = await state.get_data()
    
    # Формируем анкету
    form_data = {
        'name': data.get('name'),
        'age': data.get('age'),
        'experience': data.get('experience'),
        'skills': data.get('skills'),
        'reason': data.get('reason'),
        'username': message.from_user.username,
        'full_name': message.from_user.full_name
    }
    
    # Показываем анкету для подтверждения
    text = (
        "📋 <b>Проверьте анкету:</b>\n\n"
        f"👤 Имя: {form_data['name']}\n"
        f"🎂 Возраст: {form_data['age']}\n"
        f"💪 Опыт: {form_data['experience']}\n"
        f"🛠️ Навыки: {form_data['skills']}\n"
        f"❓ Причина: {form_data['reason']}\n\n"
        "Все верно?"
    )
    
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("✅ Да", callback_data="staff_confirm"),
                InlineKeyboardButton("❌ Нет, заново", callback_data="staff_restart")
            ]
        ]
    )
    
    await message.answer(text, reply_markup=keyboard, parse_mode="HTML")
    await state.set_state(StaffApplicationStates.waiting_for_confirm)
    await state.update_data(form_data=form_data)

@router.callback_query(F.data == "staff_confirm")
async def staff_confirm(call: CallbackQuery, state: FSMContext):
    """Подтверждение анкеты в стафф"""
    user_id = call.from_user.id
    data = await state.get_data()
    form_data = data.get('form_data')
    
    if not form_data:
        await call.answer("❌ Ошибка! Попробуйте заново.", show_alert=True)
        await state.clear()
        return
    
    # Создаем заявку в БД
    app_id = await create_application(user_id, 'staff', form_data)
    
    # Логируем
    logger: Logger = call.bot.data.get('logger')
    await logger.log_staff_application(call.from_user, form_data)
    
    # Отправляем уведомление админам
    await notify_admins_about_staff(call.bot, app_id, form_data, call.from_user)
    
    await call.message.edit_text(
        "✅ <b>Заявка в стафф отправлена!</b>\n\n"
        "Ожидайте ответа админов.",
        reply_markup=get_back_button("back_to_flood"),
        parse_mode="HTML"
    )
    await state.clear()
    await call.answer()

@router.callback_query(F.data == "staff_restart")
async def staff_restart(call: CallbackQuery, state: FSMContext):
    """Перезапуск анкеты в стафф"""
    await state.clear()
    await call.message.edit_text(
        "🔄 Начинаем заново...",
        reply_markup=get_back_button("back_to_flood")
    )
    await call.answer()

# ============ УВЕДОМЛЕНИЕ АДМИНОВ О ЗАЯВКЕ В СТАФФ ============

async def notify_admins_about_staff(bot, app_id: int, form_data: dict, user: types.User):
    """Отправляет уведомление админам о новой заявке в стафф"""
    
    text = (
        f"👔 <b>НОВАЯ ЗАЯВКА В СТАФФ!</b>\n"
        f"━━━━━━━━━━━━━━━━━━━\n\n"
        f"🆔 Заявка #<b>{app_id}</b>\n"
        f"👤 От: @{user.username} (ID: {user.id})\n\n"
        f"<b>Анкета:</b>\n"
        f"Имя: {form_data.get('name')}\n"
        f"Возраст: {form_data.get('age')}\n"
        f"Опыт: {form_data.get('experience')}\n"
        f"Навыки: {form_data.get('skills')}\n"
        f"Причина: {form_data.get('reason')}\n\n"
        f"Чтобы ответить, напишите под этим сообщением:\n"
        f"<code>Принять,Младший Админ</code> или <code>Отклонено</code>"
    )
    
    # Получаем всех админов и владельцев
    admins = await get_all_admins()
    owner_ids = config.OWNER_IDS
    
    # Отправляем каждому админу и владельцу
    for admin in admins:
        if admin['user_id'] in owner_ids or admin['role'] in ['админ', 'владелец']:
            try:
                sent_msg = await bot.send_message(
                    chat_id=admin['user_id'],
                    text=text,
                    parse_mode="HTML"
                )
                await save_staff_application_message(app_id, admin['user_id'], sent_msg.message_id)
            except Exception as e:
                print(f"Не удалось отправить админу {admin['user_id']}: {e}")
    
    # Также отправляем в канал логов
    logger: Logger = bot.data.get('logger')
    await logger.log_staff_application(user, form_data)

# ============ ОБРАБОТКА ОТВЕТОВ АДМИНОВ НА ЗАЯВКИ В СТАФФ ============

@router.message()
async def handle_staff_admin_reply(message: Message):
    """Обрабатывает ответы админов на заявки в стафф"""
    user_id = message.from_user.id
    
    # Проверяем, что это админ или владелец
    role = await get_user_role(user_id)
    if role not in ['админ', 'владелец']:
        return
    
    # Проверяем, что это ответ на сообщение бота
    if not message.reply_to_message:
        return
    
    if message.reply_to_message.from_user.id != message.bot.id:
        return
    
    # Проверяем, что в сообщении есть ID заявки в стафф
    original_text = message.reply_to_message.text
    if "ЗАЯВКА В СТАФФ" not in original_text and "Заявка #" not in original_text:
        return
    
    # Ищем ID заявки
    import re
    match = re.search(r'#(\d+)', original_text)
    if not match:
        return
    
    app_id = int(match.group(1))
    
    # Получаем заявку
    application = await get_application(app_id)
    if not application or application['status'] != 'pending' or application['type'] != 'staff':
        await message.answer("❌ Заявка уже обработана или не найдена!")
        return
    
    # Парсим ответ
    text = message.text.strip()
    
    if text.lower().startswith('принять'):
        # Формат: "Принять,Роль"
        parts = text.split(',')
        if len(parts) < 2:
            await message.answer(
                "❌ Неверный формат!\n"
                "Используйте: <code>Принять,Роль</code>\n"
                "Например: <code>Принять,Младший Админ</code>",
                parse_mode="HTML"
            )
            return
        
        role = parts[1].strip()
        
        # Проверяем, что роль существует в стаффе
        roles = await get_staff_roles()
        if role not in roles:
            await message.answer(
                f"❌ Роль <b>{role}</b> не найдена в стаффе!\n"
                f"Доступные роли: {', '.join(roles)}",
                parse_mode="HTML"
            )
            return
        
        # Принимаем заявку в стафф
        await accept_staff_application(app_id, user_id, role, message)
        
    elif text.lower() == 'отклонено':
        # Отклоняем заявку
        await reject_staff_application(app_id, user_id, message)
        
    else:
        await message.answer(
            "❌ Неверная команда!\n"
            "Используйте: <code>Принять,Роль</code> или <code>Отклонено</code>",
            parse_mode="HTML"
        )

# ============ ПРИНЯТИЕ ЗАЯВКИ В СТАФФ ============

async def accept_staff_application(app_id: int, admin_id: int, role: str, message: Message):
    """Принимает заявку в стафф"""
    application = await get_application(app_id)
    if not application:
        return
    
    user_id = application['user_id']
    
    # Обновляем статус заявки
    await update_application_status(app_id, 'accepted', admin_id, f'Принят в стафф с ролью: {role}')
    
    # Обновляем роль пользователя
    await update_user_role(user_id, 'админ')  # Назначаем админом
    await set_user_staff_role(user_id, role)
    
    # Отправляем пользователю ссылку на канал стаффа
    try:
        await message.bot.send_message(
            chat_id=user_id,
            text=(
                f"✅ <b>Поздравляем! Вы приняты в стафф!</b>\n\n"
                f"👔 Ваша роль: <b>{role}</b>\n"
                f"🔗 Ссылка на канал стаффа: {config.STAFF_CHANNEL_LINK}\n\n"
                f"Добро пожаловать в команду!"
            ),
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [InlineKeyboardButton("👔 Перейти в стафф", url=config.STAFF_CHANNEL_LINK)]
                ]
            ),
            parse_mode="HTML"
        )
        
        # Отправляем уведомление в канал стаффа
        await message.bot.send_message(
            chat_id=config.STAFF_CHANNEL_ID,
            text=(
                f"👔 <b>Новый член стаффа!</b>\n\n"
                f"👤 @{application.get('username', user_id)}\n"
                f"📋 Роль: {role}\n\n"
                f"Добро пожаловать в команду! 🎉"
            ),
            parse_mode="HTML"
        )
        
    except Exception as e:
        print(f"Не удалось отправить сообщение пользователю {user_id}: {e}")
    
    # Обновляем Info канал
    info_manager: InfoManager = message.bot.data.get('info_manager')
    await info_manager.update_staff()
    
    # Логируем
    logger: Logger = message.bot.data.get('logger')
    admin_user = await get_user(admin_id)
    user = await get_user(user_id)
    await logger.log_staff_accept(
        user=types.User(id=user_id, username=user.get('username'), full_name=user.get('full_name')),
        admin=types.User(id=admin_id, username=admin_user.get('username'), full_name=admin_user.get('full_name')),
        role=role
    )
    
    await message.answer(
        f"✅ Заявка в стафф #<b>{app_id}</b> принята!\n"
        f"👔 Роль: {role}\n"
        f"👤 Пользователь: @{user.get('username', user_id)}",
        parse_mode="HTML"
    )

# ============ ОТКЛОНЕНИЕ ЗАЯВКИ В СТАФФ ============

async def reject_staff_application(app_id: int, admin_id: int, message: Message):
    """Отклоняет заявку в стафф"""
    application = await get_application(app_id)
    if not application:
        return
    
    user_id = application['user_id']
    
    # Обновляем статус заявки
    await update_application_status(app_id, 'rejected', admin_id, 'Отклонено')
    
    # Отправляем уведомление пользователю
    try:
        await message.bot.send_message(
            chat_id=user_id,
            text=(
                "❌ <b>Ваша заявка в стафф отклонена!</b>\n\n"
                "К сожалению, администрация приняла решение отклонить вашу заявку.\n"
                "Вы можете попробовать подать заявку снова позже.",
                parse_mode="HTML"
            )
        )
    except Exception as e:
        print(f"Не удалось отправить сообщение пользователю {user_id}: {e}")
    
    # Логируем
    logger: Logger = message.bot.data.get('logger')
    admin_user = await get_user(admin_id)
    user = await get_user(user_id)
    await logger.log_staff_reject(
        user=types.User(id=user_id, username=user.get('username'), full_name=user.get('full_name')),
        admin=types.User(id=admin_id, username=admin_user.get('username'), full_name=admin_user.get('full_name'))
    )
    
    await message.answer(
        f"❌ Заявка в стафф #<b>{app_id}</b> отклонена!",
        parse_mode="HTML"
    )

# ============ ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ============

async def set_user_staff_role(user_id: int, role: str):
    """Устанавливает роль пользователя в стаффе"""
    from database import DB_PATH
    import aiosqlite
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            'UPDATE users SET staff_role = ? WHERE user_id = ?',
            (role, user_id)
        )
        await db.commit()

async def save_staff_application_message(app_id: int, admin_id: int, msg_id: int):
    """Сохраняет ID сообщения для ответа админа"""
    from database import DB_PATH
    import aiosqlite
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('''
            CREATE TABLE IF NOT EXISTS staff_app_messages (
                app_id INTEGER,
                admin_id INTEGER,
                msg_id INTEGER,
                PRIMARY KEY (app_id, admin_id)
            )
        ''')
        await db.execute(
            'INSERT OR REPLACE INTO staff_app_messages (app_id, admin_id, msg_id) VALUES (?, ?, ?)',
            (app_id, admin_id, msg_id)
        )
        await db.commit()

# ============ НАЗАД ============

@router.callback_query(F.data == "back_to_flood")
async def back_to_flood(call: CallbackQuery):
    """Возврат в меню Flood"""
    await call.message.edit_text(
        "🌊 Раздел Flood:\n\n"
        "Выберите действие:",
        reply_markup=await get_flood_menu(call.from_user.id)
    )
    await call.answer()