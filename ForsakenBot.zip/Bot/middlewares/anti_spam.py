# bot/middlewares/anti_spam.py
import time
from collections import defaultdict
from typing import Dict
from aiogram import types
from aiogram.dispatcher.middlewares.base import BaseMiddleware
from database import get_user_role

class AntiSpamMiddleware(BaseMiddleware):
    """
    Защита от спама
    """
    
    def __init__(self, limit: int = 5, window: int = 5, block_time: int = 60):
        super().__init__()
        self.limit = limit
        self.window = window
        self.block_time = block_time
        self.messages: Dict[int, list] = defaultdict(list)
        self.blocked: Dict[int, float] = {}
    
    async def __call__(self, handler, event: types.Message, data: dict):
        user_id = event.from_user.id
        
        # Проверяем роль (админы не блокируются)
        role = await get_user_role(user_id)
        if role in ['админ', 'владелец']:
            return await handler(event, data)
        
        # Проверяем блокировку
        if user_id in self.blocked:
            if time.time() < self.blocked[user_id]:
                await event.answer(
                    f"🚫 Вы заблокированы за спам!\n"
                    f"Подождите {int(self.blocked[user_id] - time.time())} сек.",
                    show_alert=True
                )
                return
            else:
                del self.blocked[user_id]
        
        # Проверяем лимит
        current_time = time.time()
        self.messages[user_id] = [
            ts for ts in self.messages[user_id]
            if current_time - ts < self.window
        ]
        self.messages[user_id].append(current_time)
        
        if len(self.messages[user_id]) > self.limit:
            self.blocked[user_id] = time.time() + self.block_time
            await event.answer(
                f"⚠️ Спам-детекция!\n"
                f"Вы заблокированы на {self.block_time} сек.",
                show_alert=True
            )
            return
        
        return await handler(event, data)